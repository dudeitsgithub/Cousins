module.exports = {
  future: {
    // removeDeprecatedGapUtilities: true,
    // purgeLayersByDefault: true,
  },
  purge: [],
  theme: {
    extend: {
      colors: {
        sammy: '#00CCFF',
      },
      fontFamily: {
        bangers: ['Bangers'],
        cool:['Permanent Marker']
      },
      fontSize: {
        mammoth: '8rem',
      }
    },
  },
  variants: {},
  plugins: [],
}
